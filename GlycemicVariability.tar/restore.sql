--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "GlycemicVariability";
--
-- Name: GlycemicVariability; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "GlycemicVariability" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "GlycemicVariability" OWNER TO postgres;

\connect "GlycemicVariability"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tablefunc; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS tablefunc WITH SCHEMA public;


--
-- Name: EXTENSION tablefunc; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION tablefunc IS 'functions that manipulate whole tables, including crosstab';


--
-- Name: delet_pat_overview(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.delet_pat_overview() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
      if (TG_OP = 'DELETE') then
        Raise exception 'STOP AND THINK ABOUT WHAT YOURE DOING';
	  end if;
	   return null;
end;
$$;


ALTER FUNCTION public.delet_pat_overview() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: eventtype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.eventtype (
    event_type text,
    event_subtype text,
    glucose_value_mgdl real,
    id smallint NOT NULL
);


ALTER TABLE public.eventtype OWNER TO postgres;

--
-- Name: EventType_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EventType_ID_seq"
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."EventType_ID_seq" OWNER TO postgres;

--
-- Name: EventType_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EventType_ID_seq" OWNED BY public.eventtype.id;


--
-- Name: dexcom; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dexcom (
    datestamp timestamp without time zone,
    glucose_value_mgdl real,
    patientid bigint,
    eventid bigint
);


ALTER TABLE public.dexcom OWNER TO postgres;

--
-- Name: demo; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.demo AS
 WITH subquery AS (
         SELECT date(dexcom.datestamp) AS pdate,
            dexcom.patientid AS pid,
            avg(dexcom.glucose_value_mgdl) AS avgglucose
           FROM public.dexcom
          GROUP BY (date(dexcom.datestamp)), dexcom.patientid
          ORDER BY (date(dexcom.datestamp)), dexcom.patientid DESC
        )
 SELECT subquery.pdate,
    subquery.pid,
    round((subquery.avgglucose)::numeric, 2) AS round,
    ((subquery.pdate - min(subquery.pdate) OVER (PARTITION BY subquery.pid)) + 1) AS patientday
   FROM subquery
  GROUP BY subquery.pdate, subquery.pid, (round((subquery.avgglucose)::numeric, 2))
  ORDER BY subquery.pid, ((subquery.pdate - min(subquery.pdate) OVER (PARTITION BY subquery.pid)) + 1);


ALTER TABLE public.demo OWNER TO postgres;

--
-- Name: demographics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.demographics (
    patientid bigint NOT NULL,
    gender text,
    hba1c numeric,
    dob date,
    firstname text,
    lastname text
);


ALTER TABLE public.demographics OWNER TO postgres;

--
-- Name: eda; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.eda (
    datestamp date,
    min_eda real,
    mean_eda real,
    max_eda real,
    patientid bigint
);


ALTER TABLE public.eda OWNER TO postgres;

--
-- Name: foodlog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.foodlog (
    datetime timestamp without time zone,
    logged_food text,
    calorie numeric,
    total_carb numeric,
    dietary_fiber numeric,
    sugar numeric,
    protein numeric,
    total_fat numeric,
    patientid bigint
);


ALTER TABLE public.foodlog OWNER TO postgres;

--
-- Name: hr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hr (
    datestamp date,
    min_hr real,
    mean_hr real,
    max_hr real,
    patientid bigint
);


ALTER TABLE public.hr OWNER TO postgres;

--
-- Name: ibi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ibi (
    patientid bigint,
    datestamp timestamp without time zone,
    mean_ibi_ms real,
    meanibi_patient_ms real,
    rmssd_ms real
);


ALTER TABLE public.ibi OWNER TO postgres;

--
-- Name: eventtype id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eventtype ALTER COLUMN id SET DEFAULT nextval('public."EventType_ID_seq"'::regclass);


--
-- Data for Name: demographics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.demographics (patientid, gender, hba1c, dob, firstname, lastname) FROM stdin;
\.
COPY public.demographics (patientid, gender, hba1c, dob, firstname, lastname) FROM '$$PATH$$/3384.dat';

--
-- Data for Name: dexcom; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dexcom (datestamp, glucose_value_mgdl, patientid, eventid) FROM stdin;
\.
COPY public.dexcom (datestamp, glucose_value_mgdl, patientid, eventid) FROM '$$PATH$$/3385.dat';

--
-- Data for Name: eda; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.eda (datestamp, min_eda, mean_eda, max_eda, patientid) FROM stdin;
\.
COPY public.eda (datestamp, min_eda, mean_eda, max_eda, patientid) FROM '$$PATH$$/3389.dat';

--
-- Data for Name: eventtype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.eventtype (event_type, event_subtype, glucose_value_mgdl, id) FROM stdin;
\.
COPY public.eventtype (event_type, event_subtype, glucose_value_mgdl, id) FROM '$$PATH$$/3382.dat';

--
-- Data for Name: foodlog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.foodlog (datetime, logged_food, calorie, total_carb, dietary_fiber, sugar, protein, total_fat, patientid) FROM stdin;
\.
COPY public.foodlog (datetime, logged_food, calorie, total_carb, dietary_fiber, sugar, protein, total_fat, patientid) FROM '$$PATH$$/3386.dat';

--
-- Data for Name: hr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hr (datestamp, min_hr, mean_hr, max_hr, patientid) FROM stdin;
\.
COPY public.hr (datestamp, min_hr, mean_hr, max_hr, patientid) FROM '$$PATH$$/3387.dat';

--
-- Data for Name: ibi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ibi (patientid, datestamp, mean_ibi_ms, meanibi_patient_ms, rmssd_ms) FROM stdin;
\.
COPY public.ibi (patientid, datestamp, mean_ibi_ms, meanibi_patient_ms, rmssd_ms) FROM '$$PATH$$/3388.dat';

--
-- Name: EventType_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EventType_ID_seq"', 16, true);


--
-- Name: demographics Demographics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.demographics
    ADD CONSTRAINT "Demographics_pkey" PRIMARY KEY (patientid);


--
-- Name: eventtype pk_evid; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eventtype
    ADD CONSTRAINT pk_evid PRIMARY KEY (id);


--
-- Name: idx_dexcom_datestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dexcom_datestamp ON public.dexcom USING btree (datestamp);


--
-- Name: idx_dexcom_patientid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dexcom_patientid ON public.dexcom USING btree (patientid);


--
-- Name: eda fkeda; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eda
    ADD CONSTRAINT fkeda FOREIGN KEY (patientid) REFERENCES public.demographics(patientid);


--
-- Name: dexcom fkevt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dexcom
    ADD CONSTRAINT fkevt FOREIGN KEY (eventid) REFERENCES public.eventtype(id);


--
-- Name: hr fkhr; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hr
    ADD CONSTRAINT fkhr FOREIGN KEY (patientid) REFERENCES public.demographics(patientid);


--
-- Name: ibi fkibi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ibi
    ADD CONSTRAINT fkibi FOREIGN KEY (patientid) REFERENCES public.demographics(patientid);


--
-- Name: dexcom fkpat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dexcom
    ADD CONSTRAINT fkpat FOREIGN KEY (patientid) REFERENCES public.demographics(patientid);


--
-- Name: foodlog fkpat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.foodlog
    ADD CONSTRAINT fkpat FOREIGN KEY (patientid) REFERENCES public.demographics(patientid);


--
-- PostgreSQL database dump complete
--

